
// const firebaseConfig = {
//   apiKey:import.meta.env.VITE_APIKEY,
//   authDomain:import.meta.env.VITE_AUTHDOMAIN,
//   projectId:import.meta.env.VITE_PROJECTID,
//   storageBucket:import.meta.env.VITE_STORAGEBUCKET,
//   messagingSenderId:import.meta.env.VITE_MESSAGINGSENDERID,
//   appId:import.meta.env.VITE_APPID,
// };

const firebaseConfig = {
  apiKey: "AIzaSyD1Ag_QzDfBVlyGaufE8xPjDEMWbMCgI28",
  authDomain: "punjabi-shops.firebaseapp.com",
  projectId: "punjabi-shops",
  storageBucket: "punjabi-shops.firebasestorage.app",
  messagingSenderId: "184248974004",
  appId: "1:184248974004:web:701d99f24bb2c27c2cf5e1"
};
  
  
export default firebaseConfig;